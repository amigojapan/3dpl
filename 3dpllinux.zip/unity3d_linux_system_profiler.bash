#!/bin/bash
# This is a tool that will help you gather information about the computer in linux and also it will gather the information about the crash of your unity program, you should distribute this program with every linux unity program you have so your users can send you the information about the crash of their program and you can submit a bug report in their behalf.
#run as:$bash unity3d_linux_system_profiler.bash your_unity_binary_name
 
 
#Unity3d crash system profiler
#Copyright Usmar A. Padow 2013 (amigojapan) usmpadow@gmail.com
#linux version
printf "Unity3d linux crash system profiler\n"
if [ -z $1 ] 
then 
printf "the first argument must be the name of the program\nand you must be in the directory containing the program\nexample: $bash unity3d_linux_system_profiler.bash myprogram\n"
exit
fi
rm Unity3d_System_Profile.txt
printf "Unity3d linux crash system profiler file\n" >>Unity3d_System_Profile.txt;
printf "Copyright Usmar A. Padow 2013 (amigojapan) usmpadow@gmail.com\n" >>Unity3d_System_Profile.txt;
printf "\n\nLinux version and kernel info:\n" >>Unity3d_System_Profile.txt;
uname -a >>Unity3d_System_Profile.txt;
cat /proc/version >>Unity3d_System_Profile.txt;
#videocard info
printf "\n\nPCI info, Videocard info, usually under VGA:\n" >>Unity3d_System_Profile.txt;
lspci -v >>Unity3d_System_Profile.txt;
#memory
printf "\n\nMemory info:\n" >>Unity3d_System_Profile.txt;
cat /proc/meminfo >>Unity3d_System_Profile.txt;
#CPU 
printf "\n\nCPU info:\n" >>Unity3d_System_Profile.txt;
cat /proc/cpuinfo >>Unity3d_System_Profile.txt;
printf "\nProgram binary name:\n" >>Unity3d_System_Profile.txt;
echo $1 >>Unity3d_System_Profile.txt;
while true; do
    read -p "Did the program exit before startinbg GUI mode?" yn
    case $yn in
        [Yy]* ) 
            printf "Processing...\n"
            printf "execution error log:\n" >>Unity3d_System_Profile.txt
            printf "standard output:\n" >>Unity3d_System_Profile.txt
            ./$1 >>Unity3d_System_Profile.txt
            printf "stderr:\n" >>Unity3d_System_Profile.txt
            ./$1 2>>Unity3d_System_Profile.txt
             printf "Please describe in one line what the bug was. press [enter when ready to submit:\n";
            read user_input
            printf "\nUser's description of bug:\n" >>Unity3d_System_Profile.txt;
            echo $user_input >>Unity3d_System_Profile.txt;
            printf "OUTPUT stored in Unity3d_System_Profile.txt\n";break;;
        [Nn]* ) 
            printf "\n\nThe program entered GUI mode succesfully\n" >>Unity3d_System_Profile.txt;
            printf "Please describe in one line what the bug was. press [enter when ready to submit:\n";
            read user_input
            printf "\nUser's description of bug:\n" >>Unity3d_System_Profile.txt;
            echo $user_input >>Unity3d_System_Profile.txt;
            printf "OUTPUT stored in Unity3d_System_Profile.txt\n";
            exit;;
        * ) printf "Please answer yes or no.";;
    esac
done
